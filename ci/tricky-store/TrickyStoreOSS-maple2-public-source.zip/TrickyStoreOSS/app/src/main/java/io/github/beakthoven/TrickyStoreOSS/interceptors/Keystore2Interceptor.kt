/*
 * Copyright 2026 Dakkshesh <beakthoven@gmail.com>
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

package io.github.beakthoven.TrickyStoreOSS.interceptors

import android.annotation.SuppressLint
import android.hardware.security.keymint.SecurityLevel
import android.os.IBinder
import android.os.Parcel
import android.system.keystore2.Domain
import android.system.keystore2.IKeystoreService
import android.system.keystore2.KeyDescriptor
import android.system.keystore2.KeyEntryResponse
import android.system.keystore2.ResponseCode
import io.github.beakthoven.TrickyStoreOSS.CertificateHack
import io.github.beakthoven.TrickyStoreOSS.CertificateUtils
import io.github.beakthoven.TrickyStoreOSS.config.PkgConfig
import io.github.beakthoven.TrickyStoreOSS.interceptors.InterceptorUtils.createTypedObjectReply
import io.github.beakthoven.TrickyStoreOSS.interceptors.InterceptorUtils.errorReply
import io.github.beakthoven.TrickyStoreOSS.interceptors.InterceptorUtils.getTransactCode
import io.github.beakthoven.TrickyStoreOSS.interceptors.InterceptorUtils.hasException
import io.github.beakthoven.TrickyStoreOSS.interceptors.InterceptorUtils.successReply
import io.github.beakthoven.TrickyStoreOSS.interceptors.InterceptorUtils.typedReply
import io.github.beakthoven.TrickyStoreOSS.logging.Logger
import io.github.beakthoven.TrickyStoreOSS.putCertificateChain

@SuppressLint("BlockedPrivateApi")
object Keystore2Interceptor : BaseKeystoreInterceptor() {
    private fun transactCode(name: String, default: Int = -1): Int =
        try {
            getTransactCode(IKeystoreService.Stub::class.java, name)
        } catch (e: Exception) {
            default
        }

    private val getKeyEntryTransaction = transactCode("getKeyEntry")
    private val deleteKeyTransaction = transactCode("deleteKey")
    private val updateSubcomponentTransaction = transactCode("updateSubcomponent")
    private val listEntriesTransaction = transactCode("listEntries")
    private val listEntriesBatchedTransaction = transactCode("listEntriesBatched")
    private val grantTransaction = transactCode("grant")
    private val ungrantTransaction = transactCode("ungrant")
    private val domainGrant: Int = Domain.GRANT

    override val interceptedCodes: IntArray by lazy {
        val codes =
            intArrayOf(
                getKeyEntryTransaction,
                deleteKeyTransaction,
                updateSubcomponentTransaction,
                listEntriesTransaction,
                listEntriesBatchedTransaction,
                grantTransaction,
                ungrantTransaction,
            )
        codes.filter { it >= 0 }.toIntArray()
    }

    private const val MIN_KEY_DESCRIPTOR_BYTES = 28
    override val serviceName = "android.system.keystore2.IKeystoreService/default"
    override val processName = "keystore2"
    override val injectionCommand = "exec ./inject `pidof keystore2` libTrickyStoreOSS.so entry"

    override fun onInterceptorSetup(service: IBinder, backdoor: IBinder) {
        check(setupSecurityLevelInterceptors(service, backdoor)) { "Failed to register keystore2 security-level interceptor" }
    }

    private fun setupSecurityLevelInterceptors(service: IBinder, backdoor: IBinder): Boolean {
        var registered = false
        val ks = IKeystoreService.Stub.asInterface(service)

        val tee = runCatching { ks.getSecurityLevel(SecurityLevel.TRUSTED_ENVIRONMENT) }.getOrNull()
        if (tee != null) {
            Logger.i("Registering for TEE SecurityLevel: $tee")
            val interceptor = SecurityLevelInterceptor(tee, SecurityLevel.TRUSTED_ENVIRONMENT)
            check(registerBinderInterceptor(backdoor, tee.asBinder(), interceptor)) { "TEE interceptor registration failed" }
            registered = true
            interceptor.loadPersistedKeys()
        } else {
            Logger.i("No TEE SecurityLevel found")
        }

        val strongBox = runCatching { ks.getSecurityLevel(SecurityLevel.STRONGBOX) }.getOrNull()
        if (strongBox != null) {
            Logger.i("Registering for StrongBox SecurityLevel: $strongBox")
            val interceptor = SecurityLevelInterceptor(strongBox, SecurityLevel.STRONGBOX)
            check(registerBinderInterceptor(backdoor, strongBox.asBinder(), interceptor)) { "StrongBox interceptor registration failed" }
            registered = true
            interceptor.loadPersistedKeys()
        } else {
            Logger.i("No StrongBox SecurityLevel found")
        }
        check(registered) { "No keystore2 security level was registered" }
        return true
    }

    override fun onPreTransact(
        target: IBinder,
        code: Int,
        flags: Int,
        callingUid: Int,
        callingPid: Int,
        data: Parcel,
    ): Result {
        if (code == deleteKeyTransaction) {
            val raw = runCatching {
                data.enforceInterface(IKeystoreService.DESCRIPTOR)
                if (data.dataAvail() < MIN_KEY_DESCRIPTOR_BYTES) return@runCatching null
                val keyDescriptor = data.readTypedObject(KeyDescriptor.CREATOR)
                Logger.d(
                    "deleteKey pre-hook: uid=$callingUid alias=${keyDescriptor?.alias} domain=${keyDescriptor?.domain}"
                )
                if (keyDescriptor != null) {
                    val resolved = SecurityLevelInterceptor.resolveAuthorizedKey(
                        callingUid,
                        keyDescriptor,
                        SecurityLevelInterceptor.Companion.AccessAction.DELETE,
                    )
                    if (resolved != null && !resolved.allowed) {
                        return@runCatching errorReply(ResponseCode.PERMISSION_DENIED, "DELETE permission not granted")
                    }
                    val key = resolved?.key
                    if (resolved?.allowed == true && key != null && SecurityLevelInterceptor.keys.containsKey(key)) {
                        if (!SecurityLevelInterceptor.cleanupKey(key.uid, key.alias)) {
                            return@runCatching errorReply(ResponseCode.SYSTEM_ERROR, "Unable to durably delete key")
                        }
                        Logger.d("deleteKey pre-hook: cleaned up uid=${key.uid} alias=${key.alias}")
                        return@runCatching successReply()
                    }
                }
                null
            }
            val result = raw.onFailure { Logger.e("deleteKey pre-hook parse failed", it) }.getOrNull()
            if (result != null) return result
            return Continue
        }

        if (code == updateSubcomponentTransaction) {
            val raw = runCatching {
                data.enforceInterface(IKeystoreService.DESCRIPTOR)
                if (data.dataAvail() < MIN_KEY_DESCRIPTOR_BYTES) return@runCatching null
                val keyDescriptor = data.readTypedObject(KeyDescriptor.CREATOR) ?: return@runCatching null
                val publicCert = data.createByteArray()
                val certificateChain = data.createByteArray()
                val resolved = SecurityLevelInterceptor.resolveAuthorizedKey(
                    callingUid,
                    keyDescriptor,
                    SecurityLevelInterceptor.Companion.AccessAction.UPDATE,
                )
                if (resolved != null && !resolved.allowed) {
                    return@runCatching errorReply(ResponseCode.PERMISSION_DENIED, "UPDATE permission not granted")
                }
                val key = resolved?.key
                if (key != null && SecurityLevelInterceptor.keys.containsKey(key)) {
                    // forged keys only exist in our maps, so the real keystore can't take the
                    // update — swallow it and patch the cached cert chain instead
                    if (!SecurityLevelInterceptor.updateKeyCertChain(key, publicCert, certificateChain)) {
                        return@runCatching errorReply(ResponseCode.SYSTEM_ERROR, "Unable to persist certificate update")
                    }
                    Logger.i("updateSubcomponent: swallowed for forged key uid=$callingUid alias=${key.alias}")
                    return@runCatching successReply()
                }
                if (key != null) {
                    // real keys keep the update in the real keystore — drop the cached response
                    // so the next read re-hacks the new chain instead of replaying the stale one
                    SecurityLevelInterceptor.patchedResponses.remove(key)
                    SecurityLevelInterceptor.skipLeafHacks.remove(key)
                    Logger.i("updateSubcomponent: forwarded, cache dropped uid=$callingUid alias=${key.alias}")
                } else {
                    Logger.i("updateSubcomponent: could not resolve alias for nspace=${keyDescriptor.nspace}")
                }
                null
            }
            val result = raw.onFailure { Logger.e("updateSubcomponent pre-hook parse failed", it) }.getOrNull()
            if (result != null) return result
            return Continue
        }

        if (code == grantTransaction && grantTransaction >= 0) {
            val raw = runCatching {
                data.enforceInterface(IKeystoreService.DESCRIPTOR)
                if (data.dataAvail() < MIN_KEY_DESCRIPTOR_BYTES) return@runCatching Skip
                val keyDescriptor = data.readTypedObject(KeyDescriptor.CREATOR) ?: return@runCatching Skip
                val granteeUid = data.readInt()
                val accessVector = data.readInt() // KeyPermission bitmap (GET_INFO=4, USE=256, …)
                val resolved = SecurityLevelInterceptor.resolveAuthorizedKey(
                    callingUid,
                    keyDescriptor,
                    SecurityLevelInterceptor.Companion.AccessAction.GRANT,
                )
                if (resolved != null && !resolved.allowed) {
                    return@runCatching errorReply(ResponseCode.PERMISSION_DENIED, "GRANT permission not granted")
                }
                val key = resolved?.key
                if (key != null && SecurityLevelInterceptor.keys.containsKey(key)) {
                    return@runCatching SecurityLevelInterceptor.withKeyLock(key) {
                        if (!SecurityLevelInterceptor.keys.containsKey(key)) return@withKeyLock Skip
                        val existing =
                            SecurityLevelInterceptor.grants.entries.firstOrNull { (_, g) ->
                                g.key == key && g.granteeUid == granteeUid
                            }
                        val grantId =
                            if (existing != null) {
                                SecurityLevelInterceptor.grants[existing.key] =
                                    existing.value.copy(accessVector = accessVector)
                                existing.key
                            } else {
                                val id = java.security.SecureRandom().nextLong()
                                SecurityLevelInterceptor.grants[id] =
                                    SecurityLevelInterceptor.GrantInfo(callingUid, granteeUid, key, accessVector)
                                id
                            }
                        val grantDescriptor = KeyDescriptor()
                        grantDescriptor.domain = domainGrant
                        grantDescriptor.nspace = grantId
                        grantDescriptor.alias = null
                        Logger.i("grant: forged grantId=$grantId alias=${key.alias} grantee=$granteeUid")
                        typedReply(grantDescriptor)
                    }
                }
                if (key != null && SecurityLevelInterceptor.isPatchedKey(key)) {
                    // real keys: let the real keystore own the grant so grant-domain operations
                    // resolve there; the post-hook records the real grantId for later lookups
                    Logger.i("grant: forwarding alias=${key.alias} grantee=$granteeUid")
                    return@runCatching Continue
                }
                Skip
            }
            return raw.onFailure { Logger.e("grant pre-hook failed uid=$callingUid", it) }.getOrNull() ?: Skip
        }

        if (code == ungrantTransaction && ungrantTransaction >= 0) {
            val raw = runCatching {
                data.enforceInterface(IKeystoreService.DESCRIPTOR)
                if (data.dataAvail() < MIN_KEY_DESCRIPTOR_BYTES) return@runCatching Skip
                val keyDescriptor = data.readTypedObject(KeyDescriptor.CREATOR) ?: return@runCatching Skip
                val granteeUid = data.readInt()
                val resolved = SecurityLevelInterceptor.resolveAuthorizedKey(
                    callingUid,
                    keyDescriptor,
                    SecurityLevelInterceptor.Companion.AccessAction.GRANT,
                )
                if (resolved != null && !resolved.allowed) {
                    return@runCatching errorReply(ResponseCode.PERMISSION_DENIED, "GRANT permission not granted")
                }
                val key = resolved?.key
                if (key != null && SecurityLevelInterceptor.keys.containsKey(key)) {
                    val removed =
                        SecurityLevelInterceptor.grants.entries.removeIf { (_, g) ->
                            g.key == key && g.granteeUid == granteeUid
                        }
                    Logger.d(
                        "ungrant: ${if (removed) "removed" else "no"} TSOSS grant for uid=$callingUid alias=${key.alias} granteeUid=$granteeUid"
                    )
                    return@runCatching successReply()
                }
                if (key != null) {
                    // real key: forward the ungrant and drop our tracking for it
                    SecurityLevelInterceptor.grants.entries.removeIf { (_, g) ->
                        g.key == key && g.granteeUid == granteeUid
                    }
                }
                Skip
            }
            return raw.onFailure { Logger.e("ungrant pre-hook failed", it) }.getOrNull() ?: Skip
        }

        if (code == getKeyEntryTransaction) {
            val raw = runCatching {
                Logger.d("intercept pre  $target uid=$callingUid pid=$callingPid dataSz=${data.dataSize()}")
                data.enforceInterface(IKeystoreService.DESCRIPTOR)
                if (data.dataAvail() < MIN_KEY_DESCRIPTOR_BYTES) {
                    Logger.w("getKeyEntry: parcel too small (${data.dataAvail()}B), forwarding")
                    return@runCatching Skip
                }
                val descriptor = data.readTypedObject(KeyDescriptor.CREATOR) ?: return@runCatching Skip
                val aliasLabel = descriptor.alias ?: "<nspace=${descriptor.nspace}>"
                val authorized = SecurityLevelInterceptor.resolveAuthorizedKey(
                    callingUid,
                    descriptor,
                    SecurityLevelInterceptor.Companion.AccessAction.GET_INFO,
                )
                if (authorized != null && !authorized.allowed) {
                    return@runCatching errorReply(ResponseCode.PERMISSION_DENIED, "GET_INFO permission not granted")
                }
                if (authorized?.provenance == SecurityLevelInterceptor.Companion.DescriptorProvenance.GRANT) {
                    val response = authorized.info?.response ?: SecurityLevelInterceptor.patchedResponses[authorized.key]
                    if (response != null) return@runCatching safeTypedObjectReply(response, "grant")
                }
                when {
                    PkgConfig.needGenerate(callingUid) -> {
                        // forwarded (non-forged) keys only live in patchedResponses — serve that
                        // cache too, or APP-domain reads diverge from GRANT-domain reads after
                        // updateSubcomponent
                        val response =
                            SecurityLevelInterceptor.findGeneratedKey(callingUid, descriptor)?.response
                                ?: SecurityLevelInterceptor.resolvePatchedResponse(callingUid, descriptor)
                        if (response != null) {
                            Logger.d("getKeyEntry: serving cache uid=$callingUid alias=$aliasLabel")
                            safeTypedObjectReply(response, "generate")
                        } else {
                            Skip
                        }
                    }
                    PkgConfig.needHack(callingUid) -> {
                        if (SecurityLevelInterceptor.shouldSkipLeafHackFor(callingUid, descriptor)) {
                            Logger.i("skip leaf hack for uid=$callingUid alias=$aliasLabel")
                            val response = SecurityLevelInterceptor.findGeneratedKey(callingUid, descriptor)?.response
                            if (response != null) {
                                Logger.d("Found generated response for uid=$callingUid alias=$aliasLabel")
                                safeTypedObjectReply(response, "skipLeafHack")
                            } else {
                                Logger.d("No generated response found for uid=$callingUid alias=$aliasLabel")
                                Continue
                            }
                        } else {
                            val patched = SecurityLevelInterceptor.resolvePatchedResponse(callingUid, descriptor)
                            if (patched != null) {
                                Logger.i("Serving cached patched response for uid=$callingUid alias=$aliasLabel")
                                safeTypedObjectReply(patched, "patched")
                            } else {
                                Logger.d("proceeding with leaf hack for uid=$callingUid alias=$aliasLabel")
                                Continue
                            }
                        }
                    }
                    else -> {
                        // generateKey forged these for non-target UIDs too — serve them back or the framework gets
                        // KEY_NOT_FOUND
                        val forged =
                            SecurityLevelInterceptor.findGeneratedKey(callingUid, descriptor)?.response
                                ?: SecurityLevelInterceptor.resolvePatchedResponse(callingUid, descriptor)
                        if (forged != null) {
                            Logger.d("Serving forged response for non-target uid=$callingUid alias=$aliasLabel")
                            safeTypedObjectReply(forged, "generated")
                        } else {
                            Skip
                        }
                    }
                }
            }
            return raw.onFailure { Logger.e("getKeyEntry pre-hook failed uid=$callingUid", it) }.getOrNull() ?: Skip
        }
        if (
            listEntriesTransaction >= 0 &&
                (code == listEntriesTransaction || code == listEntriesBatchedTransaction) &&
                (SecurityLevelInterceptor.keys.keys.any { it.uid == callingUid } ||
                    PkgConfig.needGenerate(callingUid) || PkgConfig.needHack(callingUid))
        ) {
            return Continue
        }
        return Skip
    }

    private fun safeTypedObjectReply(response: KeyEntryResponse, label: String): Result {
        val reply = runCatching { createTypedObjectReply(response) }.getOrNull()
        if (reply != null) return reply
        Logger.e("Failed to serialize KeyEntryResponse ($label), falling through to real keystore")
        return Continue
    }

    private fun mergeListEntries(callingUid: Int, code: Int, data: Parcel, reply: Parcel, resultCode: Int): Result {
        val raw = runCatching {
            if (resultCode != 0) return@runCatching Skip
            data.enforceInterface(IKeystoreService.DESCRIPTOR)
            val domain = data.readInt()
            data.readLong()
            val batched = code == listEntriesBatchedTransaction
            val startPastAlias = if (batched) data.readString() else null
            if (domain != 0) return@runCatching Skip
            if (reply.hasException()) return@runCatching Skip
            val existing = reply.createTypedArray(KeyDescriptor.CREATOR) ?: emptyArray<KeyDescriptor?>()
            val existingAliases = existing.mapNotNull { it?.alias }.toMutableSet()
            val toAdd = ArrayList<KeyDescriptor>()
            for (k in SecurityLevelInterceptor.keys.keys.filter { it.uid == callingUid }) {
                val alias = k.alias
                if (batched && startPastAlias != null && alias <= startPastAlias) continue
                if (alias in existingAliases) continue
                val kd = KeyDescriptor()
                kd.domain = 0
                kd.nspace = callingUid.toLong()
                kd.alias = alias
                toAdd.add(kd)
                existingAliases.add(alias)
            }
            if (toAdd.isEmpty()) return@runCatching Skip
            val merged: Array<KeyDescriptor> =
                (existing.filterNotNull() + toAdd).sortedBy { it.alias ?: "" }.toTypedArray()
            val p = Parcel.obtain()
            p.writeNoException()
            p.writeTypedArray(merged, 0)
            Logger.i(
                "listEntries${if (batched) "Batched" else ""}: merged ${toAdd.size} TSOSS alias(es) for uid=$callingUid"
            )
            OverrideReply(0, p)
        }
        return raw.onFailure { Logger.e("listEntries merge failed uid=$callingUid", it) }.getOrNull() ?: Skip
    }

    override fun onPostTransact(
        target: IBinder,
        code: Int,
        flags: Int,
        callingUid: Int,
        callingPid: Int,
        data: Parcel,
        reply: Parcel?,
        resultCode: Int,
    ): Result {
        if (target != keystore || reply == null) return Skip

        if (
            listEntriesTransaction >= 0 &&
                (code == listEntriesTransaction || code == listEntriesBatchedTransaction) &&
                (SecurityLevelInterceptor.keys.keys.any { it.uid == callingUid } ||
                    PkgConfig.needGenerate(callingUid) || PkgConfig.needHack(callingUid))
        ) {
            return mergeListEntries(callingUid, code, data, reply, resultCode)
        }

        if (code == deleteKeyTransaction && resultCode == 0) {
            val raw = runCatching {
                if (reply.hasException()) return@runCatching true
                data.enforceInterface(IKeystoreService.DESCRIPTOR)
                val keyDescriptor = data.readTypedObject(KeyDescriptor.CREATOR)
                if (keyDescriptor != null) {
                    val resolved = SecurityLevelInterceptor.resolveAuthorizedKey(
                        callingUid,
                        keyDescriptor,
                        SecurityLevelInterceptor.Companion.AccessAction.DELETE,
                    )
                    if (resolved?.allowed == true) {
                        SecurityLevelInterceptor.cleanupKey(resolved.key.uid, resolved.key.alias)
                    } else true
                } else true
            }
            val cleaned = raw.onFailure { Logger.e("deleteKey cleanup failed", it) }.getOrNull()
            if (cleaned == false) return errorReply(ResponseCode.SYSTEM_ERROR, "Unable to durably delete key")
            return Skip
        }

        if (code == updateSubcomponentTransaction && resultCode == 0) {
            val raw = runCatching {
                if (reply.hasException()) return@runCatching
                data.enforceInterface(IKeystoreService.DESCRIPTOR)
                val keyDescriptor = data.readTypedObject(KeyDescriptor.CREATOR)
                if (keyDescriptor != null) {
                    val resolved = SecurityLevelInterceptor.resolveAuthorizedKey(
                        callingUid,
                        keyDescriptor,
                        SecurityLevelInterceptor.Companion.AccessAction.UPDATE,
                    )
                    if (resolved?.allowed == true) {
                        SecurityLevelInterceptor.patchedResponses.remove(resolved.key)
                        SecurityLevelInterceptor.skipLeafHacks.remove(resolved.key)
                        Logger.i(
                            "Invalidated cached response for uid=$callingUid alias=${resolved.key.alias} after updateSubcomponent"
                        )
                    }
                }
            }
            raw.onFailure { Logger.e("updateSubcomponent cleanup failed", it) }
            return Skip
        }

        if (code == grantTransaction && resultCode == 0) {
            val raw = runCatching {
                if (reply.hasException()) return@runCatching
                data.enforceInterface(IKeystoreService.DESCRIPTOR)
                val keyDescriptor = data.readTypedObject(KeyDescriptor.CREATOR) ?: return@runCatching
                val granteeUid = data.readInt()
                val accessVector = data.readInt()
                val grantDescriptor = reply.readTypedObject(KeyDescriptor.CREATOR) ?: return@runCatching
                val key =
                    SecurityLevelInterceptor.resolveAuthorizedKey(
                        callingUid,
                        keyDescriptor,
                        SecurityLevelInterceptor.Companion.AccessAction.GRANT,
                    )?.takeIf { it.allowed }
                        ?.key
                        ?: return@runCatching
                if (!SecurityLevelInterceptor.isPatchedKey(key)) return@runCatching
                SecurityLevelInterceptor.grants[grantDescriptor.nspace] =
                    SecurityLevelInterceptor.GrantInfo(callingUid, granteeUid, key, accessVector)
                Logger.i("grant: tracked real grantId=${grantDescriptor.nspace} alias=${key.alias} grantee=$granteeUid")
            }
            raw.onFailure { Logger.e("grant post-hook tracking failed", it) }
            return Skip
        }

        if (reply.hasException()) return Skip
        Logger.d(
            "intercept post $target uid=$callingUid pid=$callingPid dataSz=${data.dataSize()} replySz=${reply.dataSize()}"
        )

        if (code == getKeyEntryTransaction) {
            try {
                data.enforceInterface("android.system.keystore2.IKeystoreService")
                val descriptor = data.readTypedObject(KeyDescriptor.CREATOR) ?: return Skip
                val authorized = SecurityLevelInterceptor.resolveAuthorizedKey(
                    callingUid, descriptor, SecurityLevelInterceptor.Companion.AccessAction.GET_INFO,
                )
                if (authorized != null && !authorized.allowed) return Skip
                val response = reply.readTypedObject(KeyEntryResponse.CREATOR)
                if (response != null) {
                    val cachedKey = authorized?.key
                    val presentationUid = cachedKey?.uid ?: callingUid
                    val cached = cachedKey?.let { SecurityLevelInterceptor.patchedResponses[it] }
                    if (cached != null) return createTypedObjectReply(cached)
                    val chain = CertificateUtils.run { response.getCertificateChain() }
                    if (chain != null) {
                        val newChain = CertificateHack.hackCertificateChainOrNull(chain, presentationUid) ?: return Skip
                        val patchedAuthorizations =
                            CertificateHack.patchAuthorizations(response.metadata?.authorizations, presentationUid)
                        response.putCertificateChain(newChain).getOrThrow()
                        response.metadata?.authorizations = patchedAuthorizations
                        if (cachedKey != null) SecurityLevelInterceptor.patchedResponses[cachedKey] = response
                        Logger.d("Hacked certificate for uid=$callingUid")
                        return createTypedObjectReply(response)
                    }
                }
            } catch (t: Throwable) {
                Logger.w(
                    "getKeyEntry post-hook chain patch failed for uid=$callingUid pid=$callingPid; serving unpatched real chain",
                    t,
                )
            }
        }
        return Skip
    }
}
