/*
 * Copyright 2026 Dakkshesh <beakthoven@gmail.com>
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

package io.github.beakthoven.TrickyStoreOSS.interceptors

import android.os.Binder
import android.os.IBinder
import android.os.Parcel
import io.github.beakthoven.TrickyStoreOSS.logging.Logger

open class BinderInterceptor : Binder() {

    /** Transaction codes to forward to Java hooks; empty intercepts all. */
    open val interceptedCodes: IntArray
        get() = IntArray(0)

    sealed class Result

    data object Skip : Result()

    data object Continue : Result()

    data class OverrideReply(val code: Int = 0, val reply: Parcel) : Result()

    companion object {
        private const val BACKDOOR_TRANSACTION_CODE = 0xdeadbeef.toInt()

        private const val REGISTER_INTERCEPTOR_CODE = 1

        private const val PRE_TRANSACT_CODE = 1
        private const val POST_TRANSACT_CODE = 2

        private const val RESULT_SKIP = 1
        private const val RESULT_CONTINUE = 2
        private const val RESULT_OVERRIDE_REPLY = 3

        fun getBinderBackdoor(binder: IBinder): IBinder? {
            val data = Parcel.obtain()
            val reply = Parcel.obtain()

            return try {
                val success = binder.transact(BACKDOOR_TRANSACTION_CODE, data, reply, 0)
                if (success) {
                    Logger.d("Backdoor access granted for binder: $binder")
                    reply.readStrongBinder()
                } else {
                    Logger.d("Backdoor access denied for binder: $binder")
                    null
                }
            } catch (e: Exception) {
                Logger.e("Failed to access binder backdoor", e)
                null
            } finally {
                data.recycle()
                reply.recycle()
            }
        }

        fun registerBinderInterceptor(backdoor: IBinder, target: IBinder, interceptor: BinderInterceptor): Boolean {
            val data = Parcel.obtain()
            val reply = Parcel.obtain()

            return try {
                data.writeStrongBinder(target)
                data.writeStrongBinder(interceptor)
                data.writeIntArray(interceptor.interceptedCodes)
                if (!backdoor.transact(REGISTER_INTERCEPTOR_CODE, data, reply, 0)) {
                    throw IllegalStateException("Registration transaction was not handled")
                }
                if (reply.dataSize() > 0) {
                    reply.setDataPosition(0)
                    reply.readException()
                    check(reply.dataAvail() == 0) { "Registration reply has trailing data" }
                }
                Logger.d("Registered interceptor for target: $target")
                true
            } catch (e: Exception) {
                Logger.e("Failed to register binder interceptor", e)
                false
            } finally {
                data.recycle()
                reply.recycle()
            }
        }
    }

    open fun onPreTransact(
        target: IBinder,
        code: Int,
        flags: Int,
        callingUid: Int,
        callingPid: Int,
        data: Parcel,
    ): Result = Skip

    open fun onPostTransact(
        target: IBinder,
        code: Int,
        flags: Int,
        callingUid: Int,
        callingPid: Int,
        data: Parcel,
        reply: Parcel?,
        resultCode: Int,
    ): Result = Skip

    override fun onTransact(code: Int, data: Parcel, reply: Parcel?, flags: Int): Boolean {
        return try {
            val result =
                when (code) {
                    PRE_TRANSACT_CODE -> handlePreTransact(data)
                    POST_TRANSACT_CODE -> handlePostTransact(data)
                    else -> return super.onTransact(code, data, reply, flags)
                }
            writeResultToReply(result, reply!!)
            true
        } catch (e: Throwable) {
            Logger.e("onTransact uncaught exception", e)
            try {
                reply?.setDataPosition(0)
                reply?.setDataSize(0)
                reply?.writeInt(RESULT_SKIP)
            } catch (_: Throwable) {}
            true
        }
    }

    private fun handlePreTransact(data: Parcel): Result {
        val target = data.readStrongBinder()
        val transactionCode = data.readInt()
        val transactionFlags = data.readInt()
        val callingUid = data.readInt()
        val callingPid = data.readInt()
        val dataSize = readPayloadSize(data, "pre-transaction request")
        check(dataSize == data.dataAvail()) { "Pre-transaction control message has trailing data" }

        val transactionData = Parcel.obtain()
        return try {
            transactionData.appendFrom(data, data.dataPosition(), dataSize)
            transactionData.setDataPosition(0)
            onPreTransact(target, transactionCode, transactionFlags, callingUid, callingPid, transactionData)
        } catch (e: Throwable) {
            Logger.e("handlePreTransact exception code=$transactionCode uid=$callingUid", e)
            Skip
        } finally {
            transactionData.recycle()
        }
    }

    private fun handlePostTransact(data: Parcel): Result {
        val target = data.readStrongBinder()
        val transactionCode = data.readInt()
        val transactionFlags = data.readInt()
        val callingUid = data.readInt()
        val callingPid = data.readInt()
        val resultCode = data.readInt()

        val dataSize = readPayloadSize(data, "post-transaction request")
        check(dataSize <= data.dataAvail() - Long.SIZE_BYTES) { "Truncated post-transaction request or missing reply size" }
        val requestPosition = data.dataPosition()
        data.setDataPosition(requestPosition + dataSize)
        val replySize = readPayloadSize(data, "post-transaction reply")
        check(replySize == data.dataAvail()) { "Post-transaction control message has invalid reply size" }

        val transactionData = Parcel.obtain()
        val transactionReply = Parcel.obtain()
        return try {
            transactionData.appendFrom(data, requestPosition, dataSize)
            transactionData.setDataPosition(0)
            val reply =
                if (replySize > 0) {
                    transactionReply.appendFrom(data, data.dataPosition(), replySize)
                    transactionReply.setDataPosition(0)
                    transactionReply
                } else null

            onPostTransact(
                target,
                transactionCode,
                transactionFlags,
                callingUid,
                callingPid,
                transactionData,
                reply,
                resultCode,
            )
        } catch (e: Throwable) {
            Logger.e("handlePostTransact exception code=$transactionCode uid=$callingUid", e)
            Skip
        } finally {
            transactionData.recycle()
            transactionReply.recycle()
        }
    }

    private fun readPayloadSize(data: Parcel, description: String): Int {
        val size = data.readLong()
        check(size >= 0 && size <= Int.MAX_VALUE) { "Invalid $description size: $size" }
        val sizeAsInt = size.toInt()
        check(sizeAsInt <= data.dataAvail()) { "Truncated $description: $sizeAsInt > ${data.dataAvail()}" }
        return sizeAsInt
    }

    private fun writeResultToReply(result: Result, reply: Parcel) {
        try {
            when (result) {
                Skip -> reply.writeInt(RESULT_SKIP)
                Continue -> reply.writeInt(RESULT_CONTINUE)
                is OverrideReply -> {
                    reply.writeInt(RESULT_OVERRIDE_REPLY)
                    reply.writeInt(result.code)
                    reply.writeLong(result.reply.dataSize().toLong())
                    reply.appendFrom(result.reply, 0, result.reply.dataSize())
                    result.reply.recycle()
                }
            }
        } catch (e: Throwable) {
            Logger.e("writeResultToReply exception", e)
            try {
                reply.setDataPosition(0)
                reply.setDataSize(0)
                reply.writeInt(RESULT_SKIP)
            } catch (_: Throwable) {}
        }
    }
}
