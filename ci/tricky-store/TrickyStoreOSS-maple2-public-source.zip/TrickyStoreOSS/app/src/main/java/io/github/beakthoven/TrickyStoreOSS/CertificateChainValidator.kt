/*
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

package io.github.beakthoven.TrickyStoreOSS

import java.security.KeyPair
import java.security.SecureRandom
import java.security.Signature
import java.security.cert.Certificate
import java.security.cert.X509Certificate
import java.security.interfaces.ECPrivateKey
import java.security.interfaces.RSAPrivateKey

/** Checks internal consistency before publishing a new keybox snapshot.
 * This is not a trust-anchor, revocation, or hardware-provenance check.
 */
object CertificateChainValidator {
    fun validate(keyPair: KeyPair, certificates: List<Certificate>) {
        require(certificates.isNotEmpty()) { "Empty keybox certificate chain" }
        val chain = certificates.map {
            require(it is X509Certificate) { "Non-X509 keybox certificate" }
            it
        }
        val algorithm = when (keyPair.private) {
            is ECPrivateKey -> "SHA256withECDSA"
            is RSAPrivateKey -> "SHA256withRSA"
            else -> throw IllegalArgumentException("Unsupported keybox signing algorithm")
        }
        val challenge = ByteArray(32).also { SecureRandom().nextBytes(it) }
        val signer = Signature.getInstance(algorithm)
        signer.initSign(keyPair.private)
        signer.update(challenge)
        val signature = signer.sign()
        // Prove equality mathematically; equivalent EC public keys may use
        // different legal encodings, so byte equality of SPKI is too strict.
        for (publicKey in listOf(keyPair.public, chain.first().publicKey)) {
            val verifier = Signature.getInstance(algorithm)
            verifier.initVerify(publicKey)
            verifier.update(challenge)
            require(verifier.verify(signature)) { "Keybox private key and certificate do not match" }
        }
        val encoded = chain.map { it.encoded }
        chain.forEachIndexed { index, certificate ->
            require((0 until index).none { encoded[it].contentEquals(encoded[index]) }) {
                "Duplicate certificate in keybox chain"
            }
            if (index + 1 < chain.size) {
                val issuer = chain[index + 1]
                require(certificate.issuerX500Principal == issuer.subjectX500Principal) {
                    "Keybox issuer and subject do not match"
                }
                certificate.verify(issuer.publicKey)
            } else if (certificate.issuerX500Principal == certificate.subjectX500Principal) {
                certificate.verify(certificate.publicKey)
            }
        }
    }
}
