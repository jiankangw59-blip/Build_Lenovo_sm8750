/*
 * Copyright 2026 Dakkshesh <beakthoven@gmail.com>
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

package io.github.beakthoven.TrickyStoreOSS.interceptors

import android.hardware.security.keymint.Algorithm
import android.hardware.security.keymint.KeyParameter
import android.hardware.security.keymint.KeyParameterValue
import android.hardware.security.keymint.KeyPurpose
import android.hardware.security.keymint.SecurityLevel
import android.hardware.security.keymint.Tag
import android.os.RemoteException
import android.os.ServiceSpecificException
import android.security.keymaster.KeymasterDefs
import android.system.keystore2.IKeystoreOperation
import android.system.keystore2.ResponseCode
import io.github.beakthoven.TrickyStoreOSS.CertificateGen.KeyGenParameters
import java.lang.ref.WeakReference
import java.security.Key
import java.security.KeyFactory
import java.security.MessageDigest
import java.security.Signature
import java.security.spec.MGF1ParameterSpec
import java.security.spec.X509EncodedKeySpec
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock
import kotlin.math.floor
import kotlin.math.ln
import javax.crypto.AEADBadTagException
import javax.crypto.Cipher
import javax.crypto.KeyAgreement
import javax.crypto.Mac
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.OAEPParameterSpec
import javax.crypto.spec.PSource

private const val MAX_RECEIVE_DATA = 0x8000

internal class OpRequest(
    val purpose: Int = -1,
    val digest: Int = 0,
    val digestSpecified: Boolean = false,
    val padding: Int = 0,
    val blockMode: Int = 0,
    val nonce: ByteArray? = null,
    val macLength: Int? = null,
    val mgfDigest: Int = 0,
    val mgfDigestSpecified: Boolean = false,
    val applicationId: ByteArray? = null,
    val applicationData: ByteArray? = null,
    val bindingValid: Boolean = true,
    val paddingSpecified: Boolean = false,
    val digestValid: Boolean = true,
    val paddingValid: Boolean = true,
    val mgfDigestValid: Boolean = true,
) {
    companion object {
        fun parse(params: Array<KeyParameter>): OpRequest {
            var purpose = -1
            var digest = 0
            var digestSpecified = false
            var padding = 0
            var blockMode = 0
            var nonce: ByteArray? = null
            var macLength: Int? = null
            var mgfDigest = 0
            var mgfDigestSpecified = false
            var applicationId: ByteArray? = null
            var applicationData: ByteArray? = null
            var seenApplicationId = false
            var seenApplicationData = false
            var bindingValid = true
            var paddingSpecified = false
            var digestValid = true
            var paddingValid = true
            var mgfDigestValid = true
            for (p in params) {
                try {
                    val v = p.value
                    when (p.tag) {
                        Tag.APPLICATION_ID -> {
                            if (seenApplicationId) bindingValid = false
                            seenApplicationId = true
                            applicationId = v.blob.copyOf()
                        }
                        Tag.APPLICATION_DATA -> {
                            if (seenApplicationData) bindingValid = false
                            seenApplicationData = true
                            applicationData = v.blob.copyOf()
                        }
                        Tag.PURPOSE -> purpose = v.keyPurpose
                        Tag.DIGEST -> {
                            if (digestSpecified) digestValid = false
                            digestSpecified = true
                            digest = v.digest
                        }
                        Tag.PADDING -> {
                            if (paddingSpecified) paddingValid = false
                            paddingSpecified = true
                            padding = v.paddingMode
                        }
                        Tag.BLOCK_MODE -> blockMode = v.blockMode
                        Tag.NONCE -> nonce = v.blob
                        Tag.MAC_LENGTH -> macLength = v.integer
                        Tag.RSA_OAEP_MGF_DIGEST -> {
                            if (mgfDigestSpecified) mgfDigestValid = false
                            mgfDigestSpecified = true
                            mgfDigest = v.digest
                        }
                    }
                } catch (_: Exception) {
                    if (p.tag == Tag.APPLICATION_ID || p.tag == Tag.APPLICATION_DATA) bindingValid = false
                    when (p.tag) {
                        Tag.DIGEST -> digestValid = false
                        Tag.PADDING -> paddingValid = false
                        Tag.RSA_OAEP_MGF_DIGEST -> mgfDigestValid = false
                    }
                }
            }
            return OpRequest(purpose, digest, digestSpecified, padding, blockMode, nonce, macLength, mgfDigest, mgfDigestSpecified,
                applicationId, applicationData, bindingValid, paddingSpecified, digestValid, paddingValid, mgfDigestValid)
        }
    }
}

private fun digestNameOrNull(digest: Int): String? =
    when (digest) {
        KeymasterDefs.KM_DIGEST_NONE -> "NONE"
        KeymasterDefs.KM_DIGEST_SHA1 -> "SHA1"
        KeymasterDefs.KM_DIGEST_SHA_2_224 -> "SHA224"
        KeymasterDefs.KM_DIGEST_SHA_2_256 -> "SHA256"
        KeymasterDefs.KM_DIGEST_SHA_2_384 -> "SHA384"
        KeymasterDefs.KM_DIGEST_SHA_2_512 -> "SHA512"
        else -> null
    }

private fun mgf1ParameterSpecOrNull(digest: Int): MGF1ParameterSpec? =
    when (digest) {
        KeymasterDefs.KM_DIGEST_SHA1 -> MGF1ParameterSpec.SHA1
        KeymasterDefs.KM_DIGEST_SHA_2_224 -> MGF1ParameterSpec.SHA224
        KeymasterDefs.KM_DIGEST_SHA_2_256 -> MGF1ParameterSpec.SHA256
        KeymasterDefs.KM_DIGEST_SHA_2_384 -> MGF1ParameterSpec.SHA384
        KeymasterDefs.KM_DIGEST_SHA_2_512 -> MGF1ParameterSpec.SHA512
        else -> null
    }

private data class EffectiveOperationParameters(
    val padding: Int,
    val digest: Int,
    val mgfDigest: Int,
    val digestError: Int? = null,
    val mgfDigestError: Int? = null,
    val paddingError: Int? = null,
)

private fun effectiveOperationParameters(
    keyParams: KeyGenParameters,
    op: OpRequest,
    purpose: Int = op.purpose,
): EffectiveOperationParameters {
    val rsa = keyParams.algorithm == Algorithm.RSA
    val asymmetric = rsa || keyParams.algorithm == Algorithm.EC
    val padding = if (rsa) op.padding
        else op.padding.takeIf { it != 0 } ?: keyParams.padding.firstOrNull() ?: KeymasterDefs.KM_PAD_NONE
    val digest =
        if (op.digestSpecified) op.digest
        else if (asymmetric) KeymasterDefs.KM_DIGEST_NONE
        else keyParams.digest.firstOrNull() ?: KeymasterDefs.KM_DIGEST_NONE
    val mgfDigest = if (op.mgfDigestSpecified) op.mgfDigest else KeymasterDefs.KM_DIGEST_SHA1
    val usesDigest = purpose == KeyPurpose.SIGN || (rsa && padding == KeymasterDefs.KM_PAD_RSA_OAEP)
    // KeyMint begin() requires one digest/padding tag where the algorithm uses
    // it. Key authorizations constrain the request; they are not request defaults.
    val paddingError = if (!rsa) null
        else if (!op.paddingSpecified || !op.paddingValid) KeymasterDefs.KM_ERROR_UNSUPPORTED_PADDING_MODE
        else if (purpose == KeyPurpose.SIGN && padding !in setOf(KeymasterDefs.KM_PAD_NONE,
                KeymasterDefs.KM_PAD_RSA_PSS, KeymasterDefs.KM_PAD_RSA_PKCS1_1_5_SIGN))
            KeymasterDefs.KM_ERROR_UNSUPPORTED_PADDING_MODE
        else if (purpose == KeyPurpose.DECRYPT && padding !in setOf(KeymasterDefs.KM_PAD_NONE,
                KeymasterDefs.KM_PAD_RSA_OAEP, KeymasterDefs.KM_PAD_RSA_PKCS1_1_5_ENCRYPT))
            KeymasterDefs.KM_ERROR_UNSUPPORTED_PADDING_MODE
        else null
    val rawSignature = purpose == KeyPurpose.SIGN && digest == KeymasterDefs.KM_DIGEST_NONE &&
        (keyParams.algorithm == Algorithm.EC ||
            (keyParams.algorithm == Algorithm.RSA && padding != KeymasterDefs.KM_PAD_RSA_PSS))
    val digestError =
        if (asymmetric && ((usesDigest && !op.digestSpecified) || !op.digestValid))
            KeymasterDefs.KM_ERROR_UNSUPPORTED_DIGEST
        else if (rsa && purpose == KeyPurpose.SIGN && padding == KeymasterDefs.KM_PAD_NONE &&
            digest != KeymasterDefs.KM_DIGEST_NONE) KeymasterDefs.KM_ERROR_INCOMPATIBLE_DIGEST
        else if (rsa && padding == KeymasterDefs.KM_PAD_RSA_OAEP && digest == KeymasterDefs.KM_DIGEST_NONE)
            KeymasterDefs.KM_ERROR_INCOMPATIBLE_DIGEST
        else if (
            usesDigest && (digestNameOrNull(digest) == null || (digest == KeymasterDefs.KM_DIGEST_NONE && !rawSignature))
        ) KeymasterDefs.KM_ERROR_UNSUPPORTED_DIGEST
        else if (
            keyParams.algorithm == Algorithm.RSA && padding == KeymasterDefs.KM_PAD_RSA_PSS &&
                digest == KeymasterDefs.KM_DIGEST_NONE
        ) KeymasterDefs.KM_ERROR_UNSUPPORTED_DIGEST
        else if (asymmetric && (usesDigest || op.digestSpecified) && digest !in keyParams.digest)
            KeymasterDefs.KM_ERROR_INCOMPATIBLE_DIGEST
        else if (!asymmetric && usesDigest && keyParams.digest.isNotEmpty() && digest !in keyParams.digest)
            KeymasterDefs.KM_ERROR_UNSUPPORTED_DIGEST
        else null
    val mgfDigestError =
        if (keyParams.algorithm != Algorithm.RSA || padding != KeymasterDefs.KM_PAD_RSA_OAEP) null
        else if (!op.mgfDigestValid || mgf1ParameterSpecOrNull(mgfDigest) == null)
            KeymasterDefs.KM_ERROR_UNSUPPORTED_MGF_DIGEST
        else if ((keyParams.mgfDigest.isNotEmpty() || op.mgfDigestSpecified) && mgfDigest !in keyParams.mgfDigest)
            KeymasterDefs.KM_ERROR_INCOMPATIBLE_MGF_DIGEST
        else null
    return EffectiveOperationParameters(padding, digest, mgfDigest, digestError, mgfDigestError, paddingError)
}

internal fun validateGenerationPurposes(keyParams: KeyGenParameters): Int? =
    if (KeyPurpose.ATTEST_KEY in keyParams.purpose && keyParams.purpose.any { it != KeyPurpose.ATTEST_KEY })
        KeymasterDefs.KM_ERROR_INCOMPATIBLE_PURPOSE else null

internal fun authorizeOperation(keyParams: KeyGenParameters, op: OpRequest): Int? {
    if (!op.bindingValid || !java.util.Arrays.equals(keyParams.applicationId, op.applicationId) ||
        !java.util.Arrays.equals(keyParams.applicationData, op.applicationData))
        return KeymasterDefs.KM_ERROR_INVALID_KEY_BLOB
    val purpose = op.purpose
    if (purpose < 0) return KeymasterDefs.KM_ERROR_INVALID_ARGUMENT
    val isAsymmetric = keyParams.algorithm == Algorithm.EC || keyParams.algorithm == Algorithm.RSA
    if (isAsymmetric && (purpose == KeyPurpose.VERIFY || purpose == KeyPurpose.ENCRYPT))
        return KeymasterDefs.KM_ERROR_UNSUPPORTED_PURPOSE
    if (purpose == KeyPurpose.AGREE_KEY && keyParams.algorithm != Algorithm.EC)
        return KeymasterDefs.KM_ERROR_UNSUPPORTED_PURPOSE
    if (purpose !in keyParams.purpose) return KeymasterDefs.KM_ERROR_INCOMPATIBLE_PURPOSE
    val now = System.currentTimeMillis()
    keyParams.activeDateTime?.let { if (now < it) return KeymasterDefs.KM_ERROR_KEY_NOT_YET_VALID }
    if (purpose == KeyPurpose.SIGN || purpose == KeyPurpose.ENCRYPT)
        keyParams.originationExpireDateTime?.let { if (now > it) return KeymasterDefs.KM_ERROR_KEY_EXPIRED }
    if (purpose == KeyPurpose.DECRYPT || purpose == KeyPurpose.VERIFY)
        keyParams.usageExpireDateTime?.let { if (now > it) return KeymasterDefs.KM_ERROR_KEY_EXPIRED }
    if (
        op.nonce != null &&
            (purpose == KeyPurpose.ENCRYPT || purpose == KeyPurpose.SIGN) &&
            keyParams.callerNonce != true
    )
        return KeymasterDefs.KM_ERROR_CALLER_NONCE_PROHIBITED
    val effective = effectiveOperationParameters(keyParams, op, purpose)
    effective.paddingError?.let { return it }
    effective.digestError?.let { return it }
    if (keyParams.algorithm == Algorithm.RSA && effective.padding !in keyParams.padding)
        return KeymasterDefs.KM_ERROR_INCOMPATIBLE_PADDING_MODE
    if (!isAsymmetric && keyParams.padding.isNotEmpty() && effective.padding !in keyParams.padding)
        return KeymasterDefs.KM_ERROR_UNSUPPORTED_PADDING_MODE
    if (keyParams.blockMode.isNotEmpty() && op.blockMode !in keyParams.blockMode)
        return KeymasterDefs.KM_ERROR_UNSUPPORTED_BLOCK_MODE
    effective.mgfDigestError?.let { return it }
    return null
}

private sealed interface OpEngine {
    val beginParameters: Array<KeyParameter>?
        get() = null

    fun update(data: ByteArray?): ByteArray? = null

    fun updateAad(data: ByteArray?) {
        throw ServiceSpecificException(KeymasterDefs.KM_ERROR_INVALID_TAG, "updateAad not supported")
    }

    fun finish(data: ByteArray?, signature: ByteArray?): ByteArray?
}

private class SignatureEngine(
    private val signature: Signature,
    private val verify: Boolean,
    private val rawDigestBytes: Int? = null,
) : OpEngine {
    private var acceptedBytes = 0

    private fun accept(data: ByteArray?) {
        if (data == null) return
        val count = rawDigestBytes?.let { minOf(data.size, (it - acceptedBytes).coerceAtLeast(0)) } ?: data.size
        if (count > 0) signature.update(data, 0, count)
        acceptedBytes += count
    }
    override fun update(data: ByteArray?): ByteArray? {
        accept(data)
        return null
    }

    override fun finish(data: ByteArray?, signature: ByteArray?): ByteArray? {
        accept(data)
        return if (verify) {
            if (signature == null || !this.signature.verify(signature))
                throw ServiceSpecificException(
                    KeymasterDefs.KM_ERROR_VERIFICATION_FAILED,
                    "Signature verification failed",
                )
            null
        } else {
            this.signature.sign()
        }
    }
}

/** KeyMint's undigested RSA modes accumulate at most one bounded RSA block. */
private class RawRsaSignatureEngine(privateKey: java.security.PrivateKey, private val unpadded: Boolean) : OpEngine {
    private val modulusBytes = ((privateKey as java.security.interfaces.RSAKey).modulus.bitLength() + 7) / 8
    private val maxInputBytes = modulusBytes - if (unpadded) 0 else 11
    private val input = java.io.ByteArrayOutputStream(maxInputBytes)
    private val cipher = Cipher.getInstance("RSA/ECB/${if (unpadded) "NoPadding" else "PKCS1Padding"}").apply {
        init(Cipher.ENCRYPT_MODE, privateKey)
    }

    private fun accept(data: ByteArray?) {
        if (data == null) return
        if (data.size > maxInputBytes - input.size())
            throw ServiceSpecificException(KeymasterDefs.KM_ERROR_INVALID_INPUT_LENGTH, "RSA input exceeds one block")
        input.write(data)
    }

    override fun update(data: ByteArray?): ByteArray? {
        accept(data)
        return null
    }

    override fun finish(data: ByteArray?, signature: ByteArray?): ByteArray {
        accept(data)
        val bytes = input.toByteArray()
        val block = if (unpadded) ByteArray(modulusBytes).also {
            bytes.copyInto(it, modulusBytes - bytes.size)
        } else bytes
        return cipher.doFinal(block)
    }
}

private class MacEngine(private val mac: Mac, private val verify: Boolean) : OpEngine {
    override fun update(data: ByteArray?): ByteArray? {
        if (data != null) mac.update(data)
        return null
    }

    override fun finish(data: ByteArray?, signature: ByteArray?): ByteArray? {
        if (data != null) mac.update(data)
        val tag = mac.doFinal()
        return if (verify) {
            if (signature == null || !MessageDigest.isEqual(tag, signature))
                throw ServiceSpecificException(KeymasterDefs.KM_ERROR_VERIFICATION_FAILED, "HMAC verification failed")
            null
        } else {
            tag
        }
    }
}

private class CipherEngine(private val cipher: Cipher, private val rsaCiphertextBytes: Int? = null) : OpEngine {
    private var inputBytes = 0L

    private fun accept(data: ByteArray?, finishing: Boolean) {
        inputBytes += data?.size ?: 0
        if (rsaCiphertextBytes != null &&
            (inputBytes > rsaCiphertextBytes || (finishing && inputBytes != rsaCiphertextBytes.toLong())))
            throw ServiceSpecificException(KeymasterDefs.KM_ERROR_INVALID_INPUT_LENGTH, "Invalid RSA ciphertext length")
    }
    override val beginParameters: Array<KeyParameter>? =
        cipher.iv?.let {
            arrayOf(
                KeyParameter().apply {
                    tag = Tag.NONCE
                    value = KeyParameterValue.blob(it)
                }
            )
        }

    override fun update(data: ByteArray?): ByteArray? {
        accept(data, false)
        return data?.let { cipher.update(it) }
    }

    override fun updateAad(data: ByteArray?) {
        if (data != null) cipher.updateAAD(data)
    }

    override fun finish(data: ByteArray?, signature: ByteArray?): ByteArray? {
        accept(data, true)
        return if (data != null) cipher.doFinal(data) else cipher.doFinal()
    }
}

private class KeyAgreementEngine(private val agreement: KeyAgreement) : OpEngine {
    override fun finish(data: ByteArray?, signature: ByteArray?): ByteArray? {
        if (data != null) {
            val peerKey = KeyFactory.getInstance("EC").generatePublic(X509EncodedKeySpec(data))
            agreement.doPhase(peerKey, true)
        }
        return agreement.generateSecret()
    }
}

internal class SoftwareOperationBinder
private constructor(
    private val engine: OpEngine,
    private val usageKey: SecurityLevelInterceptor.Key?,
    private val keyInfo: SecurityLevelInterceptor.Info,
    private val ownerUid: Int,
    private val level: Int,
) : IKeystoreOperation.Stub() {
    @Volatile private var active = true
    @Volatile private var lastUsedNanos = System.nanoTime()
    private val operationLock = ReentrantLock()

    // These identify the runtime platform's stable AIDL, independently of the
    // cryptographic operation state. The compile-only stub carries no version.
    override fun getInterfaceVersion(): Int = operationInterfaceVersion

    override fun getInterfaceHash(): String = operationInterfaceHash

    val beginParameters: Array<KeyParameter>?
        get() = engine.beginParameters

    @Throws(RemoteException::class)
    override fun update(input: ByteArray?): ByteArray? =
        operationLock.withLock {
            checkActive()
            try {
                checkInput(input)
                engine.update(input).also {
                    lastUsedNanos = System.nanoTime()
                }
            } catch (e: Throwable) {
                // This binder replaces keystore2's KeystoreOperation wrapper, which
                // discards the operation on every failed update, including size errors.
                active = false
                throw e
            }
        }

    @Throws(RemoteException::class)
    override fun updateAad(aadInput: ByteArray?) =
        operationLock.withLock {
            checkActive()
            try {
                checkInput(aadInput)
                engine.updateAad(aadInput)
                lastUsedNanos = System.nanoTime()
            } catch (e: Throwable) {
                active = false
                throw e
            }
        }

    @Throws(RemoteException::class)
    override fun finish(input: ByteArray?, signature: ByteArray?): ByteArray? =
        operationLock.withLock {
            checkActive()
            try {
                checkInput(input)
                SecurityLevelInterceptor.finishWithUsage(usageKey, keyInfo) {
                    engine.finish(input, signature)
                }
            } catch (e: ServiceSpecificException) {
                throw e
            } catch (e: AEADBadTagException) {
                throw ServiceSpecificException(
                    KeymasterDefs.KM_ERROR_VERIFICATION_FAILED,
                    "GCM tag verification failed",
                )
            } catch (e: Throwable) {
                throw ServiceSpecificException(
                    KeymasterDefs.KM_ERROR_VERIFICATION_FAILED,
                    e.message ?: "operation failed",
                )
            } finally {
                active = false
            }
        }

    @Throws(RemoteException::class)
    override fun abort() = operationLock.withLock {
        checkActive()
        active = false
    }

    private fun checkActive() {
        if (!active)
            throw ServiceSpecificException(
                KeymasterDefs.KM_ERROR_INVALID_OPERATION_HANDLE,
                "Operation is no longer active",
            )
    }

    private fun checkInput(data: ByteArray?) {
        if (data != null && data.size > MAX_RECEIVE_DATA)
            throw ServiceSpecificException(ResponseCode.TOO_MUCH_DATA, "Oversized input (${data.size}B)")
    }

    companion object {
        private val operationInterfaceVersion by lazy {
            IKeystoreOperation::class.java.getField("VERSION").getInt(null)
        }
        private val operationInterfaceHash by lazy {
            IKeystoreOperation::class.java.getField("HASH").get(null) as String
        }

        // AOSP's reference KeyMint TA provides 16 TEE / 4 StrongBox slots.
        // Weak references track live Binder operations without extending a
        // client's operation lifetime. Completed/error operations are reusable.
        private val operationSlots = mutableListOf<WeakReference<SoftwareOperationBinder>>()

        private fun registerOperation(operation: SoftwareOperationBinder) = synchronized(operationSlots) {
            val capacity = if (operation.level == SecurityLevel.STRONGBOX) 4 else 16
            repeat(capacity + 1) {
                operationSlots.removeAll { it.get()?.active != true }
                val live = operationSlots.mapNotNull { it.get() }.filter { it.level == operation.level }
                if (live.size < capacity) {
                    operationSlots.add(WeakReference(operation))
                    return@synchronized
                }
                val now = System.nanoTime()
                val owners = live.groupingBy { it.ownerUid }.eachCount()
                val callerMalus = 1 + (owners[operation.ownerUid] ?: 0)
                val snapshots = live.map { it to it.lastUsedNanos }
                // Keystore2 favors owners with fewer operations. Idle age adds
                // floor(log6(ageSeconds+1)); ties select the least recently used.
                fun malus(entry: Pair<SoftwareOperationBinder, Long>): Int {
                    val seconds = (now - entry.second).coerceAtLeast(0) / 1_000_000_000L
                    return owners.getValue(entry.first.ownerUid) +
                        floor(ln(seconds.toDouble() + 1.0) / ln(6.0)).toInt()
                }
                val candidate = snapshots.filter { malus(it) > callerMalus }
                    .maxWithOrNull(compareBy<Pair<SoftwareOperationBinder, Long>> { malus(it) }.thenBy { -it.second })
                    ?: snapshots.filter { it.first.ownerUid == operation.ownerUid }.minByOrNull { it.second }
                    ?: throw ServiceSpecificException(ResponseCode.BACKEND_BUSY, "All operation slots are in use")
                val previous = candidate.first
                // Admission never waits for a cryptographic call while holding
                // the registry lock; the client can retry a busy backend.
                if (!previous.operationLock.tryLock())
                    throw ServiceSpecificException(ResponseCode.BACKEND_BUSY, "Operation slot is busy")
                try {
                    if (previous.active && previous.lastUsedNanos == candidate.second) previous.active = false
                } finally {
                    previous.operationLock.unlock()
                }
            }
            throw ServiceSpecificException(ResponseCode.BACKEND_BUSY, "Operation slots changed during admission")
        }

        @JvmOverloads
        fun create(
            info: SecurityLevelInterceptor.Info,
            op: OpRequest,
            usageKey: SecurityLevelInterceptor.Key?,
            ownerUid: Int = usageKey?.uid ?: -1,
            level: Int = SecurityLevel.TRUSTED_ENVIRONMENT,
        ): SoftwareOperationBinder {
            val p = info.params
            val purpose =
                op.purpose.takeIf { it >= 0 }
                    ?: p.purpose.firstOrNull()
                    ?: throw ServiceSpecificException(
                        KeymasterDefs.KM_ERROR_INVALID_ARGUMENT,
                        "No key purpose specified",
                    )
            val effective = effectiveOperationParameters(p, op, purpose)
            effective.paddingError?.let { throw ServiceSpecificException(it, "Unsupported operation padding") }
            effective.digestError?.let { throw ServiceSpecificException(it, "Unsupported operation digest") }
            effective.mgfDigestError?.let { throw ServiceSpecificException(it, "Unsupported MGF digest") }
            val digest = effective.digest
            val padding = effective.padding
            val blockMode = op.blockMode.takeIf { it != 0 } ?: p.blockMode.firstOrNull()
            val engine: OpEngine =
                try {
                    when (p.algorithm) {
                    Algorithm.HMAC -> {
                        if (purpose != KeymasterDefs.KM_PURPOSE_SIGN && purpose != KeymasterDefs.KM_PURPOSE_VERIFY)
                            throw ServiceSpecificException(
                                KeymasterDefs.KM_ERROR_UNSUPPORTED_PURPOSE,
                                "Unsupported purpose for HMAC: $purpose",
                            )
                        if (digest == KeymasterDefs.KM_DIGEST_NONE)
                            throw ServiceSpecificException(KeymasterDefs.KM_ERROR_UNSUPPORTED_DIGEST, "HMAC requires a digest")
                        MacEngine(
                            Mac.getInstance("Hmac${operationDigestName(digest)}").apply {
                                init(
                                    info.secretKey
                                        ?: throw ServiceSpecificException(
                                            KeymasterDefs.KM_ERROR_INVALID_ARGUMENT,
                                            "HMAC operation has no secret key",
                                        )
                                )
                            },
                            purpose == KeymasterDefs.KM_PURPOSE_VERIFY,
                        )
                    }
                    Algorithm.EC,
                    Algorithm.RSA ->
                        when (purpose) {
                            KeyPurpose.SIGN ->
                                if (p.algorithm == Algorithm.RSA && digest == KeymasterDefs.KM_DIGEST_NONE)
                                    RawRsaSignatureEngine(info.keyPair!!.private, padding == KeymasterDefs.KM_PAD_NONE)
                                else SignatureEngine(
                                    Signature.getInstance(signatureAlgorithm(p.algorithm, digest, padding)).apply {
                                        initSign(info.keyPair!!.private)
                                    },
                                    false,
                                    if (p.algorithm == Algorithm.EC && digest == KeymasterDefs.KM_DIGEST_NONE)
                                        ((info.keyPair!!.private as java.security.interfaces.ECKey).params.order.bitLength() + 7) / 8
                                    else null,
                                )
                            KeyPurpose.VERIFY ->
                                SignatureEngine(
                                    Signature.getInstance(signatureAlgorithm(p.algorithm, digest, padding)).apply {
                                        initVerify(info.keyPair!!.public)
                                    },
                                    true,
                                )
                            KeyPurpose.AGREE_KEY ->
                                KeyAgreementEngine(
                                    KeyAgreement.getInstance("ECDH").apply { init(info.keyPair!!.private) }
                                )
                            KeyPurpose.ENCRYPT,
                            KeyPurpose.DECRYPT ->
                                CipherEngine(
                                    buildCipher(p, op, digest, effective.mgfDigest, padding, blockMode, info, purpose),
                                    if (p.algorithm == Algorithm.RSA && purpose == KeyPurpose.DECRYPT)
                                        ((info.keyPair!!.private as java.security.interfaces.RSAKey).modulus.bitLength() + 7) / 8
                                    else null,
                                )
                            else ->
                                throw ServiceSpecificException(
                                    KeymasterDefs.KM_ERROR_UNSUPPORTED_PURPOSE,
                                    "Unsupported purpose: $purpose",
                                )
                        }
                    Algorithm.AES ->
                        when (purpose) {
                            KeyPurpose.ENCRYPT,
                            KeyPurpose.DECRYPT ->
                                CipherEngine(buildCipher(p, op, digest, effective.mgfDigest, padding, blockMode, info, purpose))
                            else ->
                                throw ServiceSpecificException(
                                    KeymasterDefs.KM_ERROR_UNSUPPORTED_PURPOSE,
                                    "Unsupported purpose: $purpose",
                                )
                        }
                    else ->
                        throw ServiceSpecificException(
                            KeymasterDefs.KM_ERROR_UNSUPPORTED_PURPOSE,
                            "Unsupported algorithm: ${p.algorithm}",
                        )
                    }
                } catch (e: ServiceSpecificException) {
                    throw e
                } catch (e: Throwable) {
                    throw ServiceSpecificException(
                        KeymasterDefs.KM_ERROR_UNSUPPORTED_ALGORITHM,
                        e.message ?: "Software operation setup failed",
                    )
                }
            return SoftwareOperationBinder(engine, usageKey, info, ownerUid, level).also {
                registerOperation(it)
            }
        }

        private fun operationDigestName(digest: Int): String =
            digestNameOrNull(digest)
                ?: throw ServiceSpecificException(KeymasterDefs.KM_ERROR_UNSUPPORTED_DIGEST, "Unsupported digest: $digest")

        private fun signatureAlgorithm(algorithm: Int, digest: Int, padding: Int?): String {
            val keyAlgo =
                when (algorithm) {
                    Algorithm.EC -> "ECDSA"
                    Algorithm.RSA -> "RSA"
                    else ->
                        throw ServiceSpecificException(
                            KeymasterDefs.KM_ERROR_UNSUPPORTED_PURPOSE,
                            "Unsupported signature algorithm",
                        )
                }
            val name = "${operationDigestName(digest)}with$keyAlgo"
            return if (algorithm == Algorithm.RSA && padding == KeymasterDefs.KM_PAD_RSA_PSS)
                "${operationDigestName(digest)}withRSA/PSS"
            else name
        }

        private fun buildCipher(
            p: KeyGenParameters,
            op: OpRequest,
            digest: Int,
            mgfDigest: Int,
            padding: Int?,
            blockMode: Int?,
            info: SecurityLevelInterceptor.Info,
            purpose: Int,
        ): Cipher {
            val keyAlgo =
                when (p.algorithm) {
                    Algorithm.RSA -> "RSA"
                    Algorithm.AES -> "AES"
                    else ->
                        throw ServiceSpecificException(
                            KeymasterDefs.KM_ERROR_UNSUPPORTED_PURPOSE,
                            "Unsupported cipher algorithm",
                        )
                }
            val mode =
                when (blockMode) {
                    KeymasterDefs.KM_MODE_ECB -> "ECB"
                    KeymasterDefs.KM_MODE_CBC -> "CBC"
                    KeymasterDefs.KM_MODE_CTR -> "CTR"
                    KeymasterDefs.KM_MODE_GCM -> "GCM"
                    else -> "ECB"
                }
            val pad =
                when (padding) {
                    KeymasterDefs.KM_PAD_NONE -> "NoPadding"
                    KeymasterDefs.KM_PAD_RSA_OAEP -> "OAEPPadding"
                    KeymasterDefs.KM_PAD_RSA_PKCS1_1_5_ENCRYPT,
                    KeymasterDefs.KM_PAD_RSA_PKCS1_1_5_SIGN -> "PKCS1Padding"
                    KeymasterDefs.KM_PAD_PKCS7 -> "PKCS7Padding"
                    else -> "NoPadding"
                }
            val opMode = if (purpose == KeyPurpose.ENCRYPT) Cipher.ENCRYPT_MODE else Cipher.DECRYPT_MODE
            return Cipher.getInstance("$keyAlgo/$mode/$pad").apply {
                val spec: java.security.spec.AlgorithmParameterSpec? =
                    when {
                        blockMode == KeymasterDefs.KM_MODE_GCM ->
                            GCMParameterSpec(op.macLength ?: 128, op.nonce ?: ByteArray(12))
                        padding == KeymasterDefs.KM_PAD_RSA_OAEP ->
                            OAEPParameterSpec(
                                operationDigestName(digest).replace("SHA", "SHA-"),
                                "MGF1",
                                mgf1ParameterSpecOrNull(mgfDigest)
                                    ?: throw ServiceSpecificException(
                                        KeymasterDefs.KM_ERROR_UNSUPPORTED_MGF_DIGEST,
                                        "Unsupported MGF digest: $mgfDigest",
                                    ),
                                PSource.PSpecified.DEFAULT,
                            )
                        op.nonce != null -> IvParameterSpec(op.nonce)
                        else -> null
                    }
                val key: Key =
                    when {
                        info.secretKey != null -> info.secretKey
                        opMode == Cipher.ENCRYPT_MODE -> info.keyPair!!.public
                        else -> info.keyPair!!.private
                    }
                if (spec != null) init(opMode, key, spec) else init(opMode, key)
            }
        }
    }
}
