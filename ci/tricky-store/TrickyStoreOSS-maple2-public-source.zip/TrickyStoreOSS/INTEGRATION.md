# Tricky Store OSS compat10-maple.2 integration

This is a local GPL-3.0-or-later integration, not an upstream release. It remains a
single `tricky_store` module. Existing per-application `security_patch.txt` and
`target.txt` policies are retained.

## Sources and conflict decisions

| Source | Incorporated | Boundary |
| --- | --- | --- |
| TrickyStoreOSS `f9c220717ff6aaa209229fb2bcf20eba83107702` | Native Binder transport, daemon, application scope, owner/grant checks, per-app patch policy | Runtime source matches the installed v201 base; native binaries are reused from the supplied official release |
| TrickyStoreOSS Compat `v3.1.0-199-compat.10`, base `dda5277d10b948ba6bec362252ec41f8bbbd9f97` | Supported EC/RSA generation and PKCS8 import, application binding, parent certificate chain, operation validation/lifecycle, alias replacement and usage state | No extra randomized operation delays, global boot-property rewrites, PIF-comment heuristics, or private system SQLite inventory query |
| TEESimulator-MapleSU `v6.0.36`, `31418d726fa8ee242dfec0a378a0769572f1b4af` | Reference behavior for certificate encoding and component patch-date selection; conflicting patch semantics follow MapleSU | No second daemon, Rust core replacement, Soter integration, or TEES persistent storage migration |

The MapleSU checkout distributes its Rust certificate core as a prebuilt library.
This integration does not claim to rebuild that missing source or reproduce its
opaque internal key blobs.

## maple.2 operation usage lifecycle

The installed maple.1 implementation could release a second signature from an
already-open operation after the first completion exhausted and removed its
alias. Removing the alias also removed its counters; an identity guard then
mistook the missing record for an unrelated replacement and skipped accounting.

The correction follows OhMyKeymint's completion-time model: opening an operation
does not consume a use; completion checks the generation's shared budget before
cryptography, commits only successful completion, and returns output only after
accounting succeeds. Operations retain their original generation's budget after
alias retirement. Replacement keys have independent budgets and persistent data.
Failed operations and abort do not consume a use. Existing Tricky usage-state
serialization and failure handling remain authoritative; no OhMyKeymint binary,
storage file, or persistence format is imported.
Reloading the same persisted generation retains its live operation budget rather
than replacing it with another in-memory counter. A different namespace, security
level, or key material remains a different generation.

Reference: ITxiao6666/OhMyKeymint release tag `v1.4.3-263-6f54f1e`, currently
resolved source revision `ffd2fcc04ab1d0465b055c79a998b528116b8637`,
`ta/src/usage.rs`, `ta/src/operation/begin.rs`, and `ta/src/operation.rs`.
The ZIP filename's short identifier was not independently resolved as a source
commit. The reference's volatile counter table and full-table reset behavior
are not adopted.

## Certificate and metadata consistency

- Keep the requested Subject DER, including RDN order and ASN.1 string types.
- Validate a keybox's signing key pair, certificate order and signatures before
  atomically publishing a new snapshot. Failed reload retains the previous one.
- Rebuild an existing AKI for the replacement issuer, preserving criticality.
- If a certificate cannot be patched, preserve both the original certificate and
  its original authorization metadata. Clear stale legacy leaf/CA associations.
- Keep attestation extension patch fields and returned metadata aligned.
- Preserve the caller's challenge. No-challenge EC/RSA certificates do not claim
  to contain an attestation extension.
- Software parent attestation keys must have an explicit supported no-auth policy.
  Parent application binding and usage limits are rejected until their distinct
  parent authorization/consumption contract is supported; signing validity dates
  and owner/grant permissions are enforced.

Keybox validation checks internal consistency. It does not establish hardware
provenance, external trust, non-revocation, or repair the physical TEE.

## Patch dates

Resolution remains application component, application `all`, global component,
then global `all`. Explicit dates and `no` retain their meaning. Following
MapleSU, explicit `prop` uses the system security-patch property for all components.
Unset / `device_default` preserves the original component when patching a real
certificate. Generation prefers the actual attested vendor/boot patch date,
then a component patch property, finally the system patch date. Build timestamps
are not treated as security-patch dates. A shared UID still cannot distinguish
individual package callers reliably.

## Storage contract

**These formats are deliberately not interchangeable:**

| Implementation | Path / record key | Version header |
| --- | --- | --- |
| Tricky Store OSS | `keys/<uid>/SHA256(alias).bin` | One-byte version, then Tricky parameters/metadata/owner/usage state |
| TEESimulator-MapleSU Java persistence | `persistent_keys/SHA256(uid + ":" + alias)` | Four-byte integer version; different layout |

The Tricky loader accepts versions 3, 4 and 5. Unbound records still serialize as
4. Version 5 is used only when APPLICATION_ID or APPLICATION_DATA is present,
including a present-but-empty binding. Version 5 appends these fields to the
Tricky layout; it is not a TEES format. Loading does not migrate or rewrite old
records. Existing ownership and authentication restrictions remain in force.

An older Tricky version that only reads 3/4 cannot read newly created format-5
records. Rollback therefore requires keeping this newer loader or restoring a
consistent pre-upgrade backup, rather than renaming key files. Installation does
not touch `persistent_keys`, `key_db`, Android's `persistent.sqlite`, existing
keybox, targets or patch configuration. Conflicting active modules cause an
installation error instead of silently being scheduled for deletion.

## Verification and reproduction

The accompanying tests run compiled production code in isolated host/device
processes with synthetic keys. They do not initialize the module or request keys
from AndroidKeyStore. Optional installed-keybox validation reads it only on the
device and prints algorithms/counts, never key material.

Build from the pinned TrickyStoreOSS checkout with the included integration diff.
Use the upstream Gradle 9.8.1 / JDK 26 / SDK 37 configuration. The debug APK used
for probes excludes native libraries. The install ZIP combines the optimized
release DEX with unchanged arm64 native libraries from the supplied official
v201 release. Do not install the debug probe ZIP generated by Gradle.

See the package's validation report for the distinction between isolated checks,
staged installation, and verification after a device reboot.
